#include <iostream>
#include <cmath>
#include <string>
#include <Possion1d_Kernel.h>
using namespace std;



double Afunc(double x)
{
	return 0.5+0.7*x;
}

double func(double x)
{
	return 0.3*x*x;
}

int main()
{
	/*  -(au`)` = f  , x 属于 I=[0,L]
	 *   au`(0) = k0(u(0)-g0)
	 *  -au`(L) = kL(u(L)-gL)
	
	  n：区间分割的段数
	  L：区间终点的坐标（起点为0）
	  k0,kL,g0,gL都是给定的参数
	*/
	int n = 10;
	double L = 6;
	double k0 = 1000000;
	double kL = 0;
	double g0 = -1;
	double gL = 0;
	
	//假设是一个均匀剖分
	double h = L/n;
	
	//生成刚度矩阵和重载向量的容器
	AssembleVector I(n+1);
	AssembleMatrix A(n+1);

	//组装刚度矩阵和重载向量
	I.Assemble(h,func);
	A.Assemble(h,Afunc);
	A[0][0] += k0;
	A[n][n] += kL;
	I[0]  += k0*g0;
        I[n]  += kL*gL;

	//输出装载好的刚度矩阵和重载向量
	cout << A <<endl;
	cout << I <<endl;
		
	//利用GaussSeidel迭代求方程组
	Vector x(n+1);
	A.GaussSeidel(I,x,10000);
	//输出方程组的求解结果
	cout << x <<endl;	
}
