#ifndef Matrix_h
#define Matrix_h

#include <Vector.h>
#include <iostream>
#include <cmath>
#include <string>
using namespace std;

class Matrix
{
public:
	//等价于double  *data[] 表示一个指针类型的数组
	double **data;
	int shape[2];
	Matrix()
	{
		shape[0] = shape[1] = 0;
		data = NULL;
	}
	Matrix(int n,double var = 0.0)
	{
		shape[0] =shape[1] = n;
		//开辟指针数组，数组长度为shape[0]
		data = new double *[shape[0]];
		for(int i = 0;i < shape[0];i ++)
		{
			/*开辟double类型，长度为shape[1]的
			  数组，首地址给data[i]*/
			data[i] = new double[shape[1]];
			for(int j = 0;j < shape[1];j++)
			{
				data[i][j] = var;
			}
		}
	}
	~Matrix()
	{
		if(data != NULL)
			delete[] data;
	}
	//重载运算符
	double * operator [](int i)
	{
		return data[i];
	}
};
//重载 输出 运算符
ostream& operator <<(ostream &out , Matrix &p)
{
	cout << "M(" << p.shape[0]<<","<<p.shape[1]<<")"<<endl;
	for(int i=0;i<p.shape[0];i++)
	{	
		for(int j=0;j<p.shape[1];j++)
		{	out << p[i][j]<<" ";}
		out<<endl;
	}
	return out;
}
#endif
