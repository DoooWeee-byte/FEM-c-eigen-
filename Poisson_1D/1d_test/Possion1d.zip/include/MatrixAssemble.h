#ifndef MatrixAssemble_h
#define MatrixAssemble_h

#include <Matrix.h>
#include <iostream>
#include <cmath>
#include <cassert>

using namespace std;
//用于进行数值积分的计算
class MatrixQua :public Matrix
{
public:
	//调用父类的构造函数
	MatrixQua(int n=2,double var = 0.0):Matrix(n,var){}
	
	//中点值算积分
	void MidQuadra(double h,double xm, double (*func)(double) )
	{
	//int (*functionname)(double) 表示有一个double形参，返回值为int的函数指针
		for(int i = 0;i < shape[0];i++)
		{
			for(int j = 0;j < shape[0];j++)
			{	
				data[i][j] = pow(-1,i+j)*func(xm)/h;
			}	
		}
	}
};

//进行刚度矩阵的组装
class AssembleMatrix :public Matrix
{
public:
	MatrixQua m;
	AssembleMatrix(int n,double var = 0.0):Matrix(n,var){}
	void Assemble(double h,double (*func)(double))
	{
	//n+1阶的刚度矩阵需要循环n次
		for(int k = 0;k < shape[0]-1;k++)
		{	
			//求出区间中点的坐标
			 double xm = (2*k+1)/2.0 * h;
			 //从小矩阵赋值到大矩阵
          		 m.MidQuadra(h, xm, func);
			 for(int i = 0;i < m.shape[0];i ++)
			 {      	
		       	       for(int j = 0;j < m.shape[0];j++)
                       	       {
                                     data[k+i][k+j] += m[i][j];
                       	       }
               	 }

		}
	}

	void GaussSeidel(Vector &b,Vector &x,int max = 1000,double tol = 1e-8)
	{	
		assert( shape[1] == b.size );
		double bnorm = 0;
		//计算b向量的范数
		for(int i = 0;i<b.size;i++)
		{
			bnorm += b[i]*b[i];
		}
		bnorm = sqrt(bnorm);
		cout << bnorm <<endl;
		double d = 0;
		
		for(int k = 0;k < max ; k++)
		{	
			double norm = 0;
			for(int i = 0;i < x.size;i++)
			{
				x[i] = b[i];
				for(int j = 0;j < x.size;j++)
				{
					if(j != i)
					{
						x[i] -=  x[j]*data[i][j];
					}else
					{
						d= data[i][i];
					}
				}
				x[i] /= d;
			}
			//用b - Ax的范数来衡量求解的误差
			for(int r = 0;r < x.size;r++ )
			{
				Vector x1(b.size);
				for(int c =0;c < x.size;c ++)
				{
					x1[r] += x[c]*data[r][c];	
				}
				x1[r] = b[r] - x1[r];
				norm += x1[r]*x1[r];
			}
			norm = sqrt(norm);
			cout <<k << " "<< norm <<endl;
			if(norm < tol*bnorm)
				break;
		}
	}
		
};
#endif
