#ifndef Vector_h
#define Vector_h

#include <iostream>
#include <cmath>
#include <string>
using namespace std;
class Vector
{
public:
	int size;
	double *data;
	Vector()
	{
		size = 0;
		data = NULL;
	}
	Vector(int n,double var = 0.0)
	{	
		size = n;
		data = new double[n];
		for(int i = 0;i < n;i ++)
		{
			data[i] = var;
		}
	}
	~Vector()
	{	
		if(data != NULL)
			delete[] data;
	}
	double &  operator[] (int i)
	{
		return data[i];
	}	
};
ostream& operator << (ostream &out, Vector &v)
{
	cout<<"Vector("<<v.size<<")"<<endl;
	for(int i=0;i<v.size;i++)
	{
		out << v[i]<< " ";
	}
	out << endl;
	return out;
}
#endif
