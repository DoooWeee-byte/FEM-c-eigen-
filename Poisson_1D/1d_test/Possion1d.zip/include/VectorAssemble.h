#ifndef VectorAssemble_h
#define VectorAssemble_h

#include <Vector.h>
#include <iostream>
#include <cmath>

using namespace std;

//组装重载向量
class AssembleVector : public Vector
{
public:
	AssembleVector(int n,double var = 0.0):Vector(n,var){}
	void Assemble(double h,double (*func)(double))
	{
		for(int k = 0;k < size;k++)
		{
			double xi = k*h;
			if(k != 0&& k != size-1)
				data[k] = func(xi)*h;
			else
				data[k] = func(xi)*h/2.0;
		}
	}
};
#endif
